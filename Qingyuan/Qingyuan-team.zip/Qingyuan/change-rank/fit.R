# Uses the Phase 10 parameterization and its order of penalties within each pair.
change_rank_grid <- function() {
  pairs <- expand.grid(L=c(2L,4L),D=c(8L,9L,10L,12L,16L),KEEP.OUT.ATTRS=FALSE)
  old <- rank_grid()
  methods <- old[old$L==4 & old$D==8 & old$method %in% c("ridge","lasso"),]
  do.call(rbind,lapply(seq_len(nrow(pairs)), function(i) {
    z <- methods
    z$L <- pairs$L[i]
    z$D <- pairs$D[i]
    z$id <- sprintf("L%d_D%d_%s",z$L,z$D,sub(".*_","",z$id))
    z
  }))
}

change_rank_fit <- function(training,metadata,grid=change_rank_grid()) {
  rank_fit(training,metadata,grid,registry=change_rank_grid())
}

# Descriptive training-fold quantities. The change energy uses all adjacent
# calendar days within training years, the same two-endpoint missingness policy
# as forecasting, and the exact basis of the fitted model.
change_rank_diagnostics <- function(fit,training) {
  u <- fit$prepared
  all_axes <- cbind(u$pc12[,1:8,drop=FALSE],u$extra_change_axes)
  ordered <- sort(training$dates)
  previous <- head(ordered,-1L)
  current <- tail(ordered,-1L)
  paired <- (as.integer(current-previous)==1L) & calendar_year(current)==calendar_year(previous)
  z <- p8_change(u,training,current[paired])$z
  energy <- colSums((z %*% all_axes)^2)
  total <- sum(z^2)
  explained <- c(u$pc12_fraction[1:8],u$extra_level_fractions)
  grid <- fit$grid
  coef <- fit$coefficients
  do.call(rbind,lapply(seq_len(nrow(grid)),function(i) {
    upper <- grid$D[i]
    ix <- seq_len(upper)
    additional <- if (upper>8L) paste0("dpc",9:upper) else character()
    active <- if (length(additional))
      apply(abs(coef[additional,,i,,drop=FALSE])>1e-9,2L,sum)/dim(coef)[4L] else rep(0,5L)
    data.frame(id=grid$id[i],horizon=1:5,level_fraction=sum(explained[ix]),
      change_energy_fraction=if (total>0) sum(energy[ix])/total else 0,
      active_changes_beyond_8=as.numeric(active))
  }))
}
