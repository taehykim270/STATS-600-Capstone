# STATS 600 weather forecasts

Open **report.pdf** for the model and its 2014 results. **report.tex** is the editable source.

To run the code, put the course file `weather.rda` in the `data/` folder. Open a terminal in the extracted `Qingyuan/` folder and use R.

## Check the 2014 score

```sh
Rscript --vanilla scripts/score_2014.R data/weather.rda results/2014_mse.csv
```

This matches the saved 2,700 forecasts to the original temperatures. The pooled MSE in `results/2014_mse.csv` is 35.863 °F².

## Forecast a later year

Place that year's course input (days 1–15 of each month) at `data/unseen.rda`. Replace 2015 below with the year supplied.

```sh
Rscript --vanilla scripts/predict.R data/weather.rda data/unseen.rda 2015 results/forecast.csv
```

The default uses the two-band Ridge settings selected from 2005–2014. The 2,700 forecasts are written to `results/forecast.csv`.

## Files the two scripts read

| File | Purpose |
|---|---|
| `handoff/2014_forecasts.csv` | The 2,700 saved 2014 forecasts, before and after enforcing temperature order. |
| `change-rank/results/choices.csv` | Settings used to forecast **2014**, selected with 2005–2013 data. Days 16–17 use 4 level PCs and 16 change PCs. Days 18–20 use 4 and 5. |
| `results/recommended.csv` | Settings for a year **after 2014**, selected with 2005–2014 data. Days 16–17 use 4 level PCs and 16 change PCs. Days 18–20 use 4 and 8. |
| `data/airport_metadata.csv` | Coordinates for the 98 airports, used to find neighbors and estimate pressure gradients. |
| `R/inherited.R` | Reads weather data, estimates seasonal averages, constructs spatial features and enforces temperature order. |
| `R/model.R` | Builds the regression inputs, fits the coefficients and calculates forecasts. |
| `rank-study/fit.R` | Fits models with separate numbers of PCA levels and daily changes. |
| `change-rank/fit.R` | Defines additional change ranks, including the 16 components used for days 16–17. |
