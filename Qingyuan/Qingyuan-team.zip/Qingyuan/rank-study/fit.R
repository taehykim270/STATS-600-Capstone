# Source R/inherited.R and R/model.R first. L and D index the same training-
# year PCA basis. The two blocks may retain different numbers of leading axes.
rank_grid <- function() {
  ranks <- c(2L,4L,5L,6L,8L)
  pairs <- rbind(expand.grid(L=ranks,D=ranks,KEEP.OUT.ATTRS=FALSE),
                 data.frame(L=c(5L,0L,0L),D=c(0L,5L,0L)))
  settings <- data.frame(suffix=c("ols","ridge03","ridge30","lasso03","lasso15"),
                         method=c("ols","ridge","ridge","lasso","lasso"),
                         penalty=c(0,.03,.30,.03,.15))
  designs <- pairs[rep(seq_len(nrow(pairs)),each=nrow(settings)),]
  settings <- settings[rep(seq_len(nrow(settings)),nrow(pairs)),]
  data.frame(id=sprintf("L%d_D%d_%s",designs$L,designs$D,settings$suffix),
             L=designs$L,D=designs$D,method=settings$method,penalty=settings$penalty)
}

rank_fit <- function(training,metadata,grid=rank_grid(),registry=rank_grid()) {
  ix <- match(grid$id,registry$id)
  stopifnot(nrow(grid)>0L,!anyNA(ix),!anyDuplicated(ix))
  # Resolve feature definitions and penalty values from the registered ids.
  grid <- registry[ix,,drop=FALSE]
  key <- sprintf("L%d_D%d",grid$L,grid$D)
  pairs <- grid[!duplicated(key),c("L","D")]
  base <- q_groups(q_grid())$none_0
  groups <- Map(function(L,D) {
    c(base,if (L>0L) paste0("pc",seq_len(L)),if (D>0L) paste0("dpc",seq_len(D)))
  },pairs$L,pairs$D)
  names(groups) <- unique(key)
  q_fit(training,metadata,grid,groups,key,max_change_rank=max(8L,grid$D))
}
