# Fit on the supplied historical archive and forecast one new calendar year.
# From any directory: Rscript --vanilla PATH/TO/Qingyuan/scripts/predict.R
#   HISTORICAL.rda UNSEEN.rda YEAR OUTPUT.csv [ID or ID1,ID2,ID3,ID4,ID5]
script <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))
root <- dirname(dirname(normalizePath(script)))
source(file.path(root, "R", "inherited.R"))
source(file.path(root, "R", "model.R"))
source(file.path(root, "rank-study", "fit.R"))
source(file.path(root, "change-rank", "fit.R"))

args <- commandArgs(TRUE)
assert(length(args) %in% 4:5,
       "Usage: predict.R HISTORICAL.rda UNSEEN.rda YEAR OUTPUT.csv [ID or five comma-separated IDs]")
assert(grepl("^[0-9]{4}$", args[3]), "The forecast year must be a four-digit year")
year <- valid_year(as.integer(args[3]))
if (length(args) == 5L) {
  ids <- strsplit(args[5], ",", fixed = TRUE)[[1]]
  if (length(ids) == 1L) ids <- rep(ids, 5L)
} else {
  choice <- read.csv(file.path(root, "results", "recommended.csv"), stringsAsFactors = FALSE)
  assert(all(c("horizon", "id") %in% names(choice)) &&
         identical(sort(choice$horizon), 1:5), "Expected one recommendation per horizon")
  ids <- choice$id[match(1:5, choice$horizon)]
}
rank_specs <- rank_grid()
extra <- change_rank_grid()
rank_specs <- rbind(rank_specs,extra[!extra$id %in% rank_specs$id,])
assert(length(ids) == 5L && all(ids %in% c(q_grid()$id,rank_specs$id)),
       "Unknown model ID or incorrect number of IDs")

metadata <- read.csv(file.path(root, "data", "airport_metadata.csv"), stringsAsFactors = FALSE)
history <- read_weather(args[1], historical = TRUE)
assert(!year %in% calendar_year(history$dates), "Forecast year occurs in the training archive")
# The context reader first strips all dates beyond day 15, then validates and
# normalizes supplied measurement columns. Forecast generation never sees labels.
context <- p51_read_context(args[2], year, metadata)$data
neighbors <- p3_neighbors(metadata)
training <- p5_raw(history, neighbors, metadata)
training <- p45_subset(training, rep(TRUE, length(training$dates)))
issued <- p5_raw(context, neighbors, metadata)
issued <- p45_subset(issued, rep(TRUE, length(issued$dates)))
wanted <- unique(ids)
old_ids <- intersect(wanted,q_grid()$id)
rank_ids <- intersect(wanted,rank_specs$id)
predictions <- list()
if (length(old_ids))
  predictions$original <- q_predict(q_fit(training,metadata),issued,ids=old_ids)
if (length(rank_ids)) {
  # Keep the full penalty path within each requested feature pair so Lasso
  # uses the same warm starts as in validation.
  pairs <- paste(rank_specs$L,rank_specs$D,sep="_")
  keep <- pairs %in% pairs[match(rank_ids,rank_specs$id)]
  rank_model <- rank_fit(training,metadata,rank_specs[keep,],registry=rank_specs)
  predictions$independent <- q_predict(rank_model,issued,ids=rank_ids)
}
raw <- do.call(cbind,unname(predictions))
grid <- forecast_grid(year)
assert(is.matrix(raw) && nrow(raw) == nrow(grid) && all(ids %in% colnames(raw)),
       "Prediction dimensions do not match the forecast grid")
grid$model <- if (length(unique(ids)) == 1L) ids[1] else paste(ids, collapse = "+")
grid$prediction <- raw[cbind(seq_len(nrow(grid)), match(ids[grid$horizon], colnames(raw)))]
out <- p4_order_forecasts(grid, year)
assert(nrow(out) == 2700L && !anyDuplicated(prediction_key(out)) &&
       all(is.finite(out$prediction)), "Invalid forecast output")
write.csv(out, args[4], row.names = FALSE)
