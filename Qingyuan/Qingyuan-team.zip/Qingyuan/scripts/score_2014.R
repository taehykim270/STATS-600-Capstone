#!/usr/bin/env Rscript
# Rescore the saved, earlier-years-only 2014 predictions against the original RDA.
args <- commandArgs(trailingOnly=TRUE)
if (length(args)!=2L)
  stop("Usage: Rscript scripts/score_2014.R data/weather.rda results/2014_mse.csv")
script <- sub("^--file=", "", grep("^--file=", commandArgs(), value=TRUE))
root <- dirname(dirname(normalizePath(script)))
source(file.path(root,"R","inherited.R"))
history <- read_weather(args[1],historical=TRUE)
saved <- read.csv(file.path(root,"handoff","2014_forecasts.csv"))
grid <- forecast_grid(2014L)
key <- prediction_key(saved)
idx <- match(prediction_key(grid),key)
stopifnot(nrow(saved)==2700L,!anyDuplicated(key),!anyNA(idx))
saved <- saved[idx,]
stopifnot(all(saved$year==grid$year),all(saved$month==grid$month),
          all(saved$origin_date==format(grid$origin_date)),all(saved$horizon==grid$horizon),
          all(is.finite(saved$raw_prediction)),all(is.finite(saved$prediction)))

choices <- read.csv(file.path(root,"change-rank","results","choices.csv"))
fold <- subset(choices,protocol=="forward" & year==2014L & policy=="ridge_wide_band")
stopifnot(nrow(fold)==5L,setequal(fold$horizon,1:5),all(fold$training==paste(2005:2013,collapse="|")),
          all(fold$inner_years==paste(2008:2013,collapse="|")),
          identical(saved$model,fold$id[match(grid$horizon,fold$horizon)]))
ordered <- as.numeric(p51_order_matrix(matrix(saved$raw_prediction,ncol=1L)))
stopifnot(max(abs(saved$prediction-ordered))<1e-10)

# Directly index original daily temperature columns. Every label is observed.
fields <- paste(grid$airport,TARGET_FIELDS[grid$target],sep="_")
raw_targets <- as.matrix(history$values[unique(fields)])
truth <- raw_targets[cbind(match(grid$target_date,history$dates),match(fields,colnames(raw_targets)))]
stopifnot(length(truth)==2700L,all(is.finite(truth)))
loss <- (ordered-truth)^2
groups <- c(list(pooled=seq_along(loss)),split(seq_along(loss),factor(grid$target,levels=c("max","mean","min"))))
scores <- data.frame(period="2014",target=names(groups),n=lengths(groups),
                     sse=vapply(groups,function(i) sum(loss[i]),0.0),
                     mse=vapply(groups,function(i) mean(loss[i]),0.0),row.names=NULL)
dir.create(dirname(args[2]),recursive=TRUE,showWarnings=FALSE)
write.csv(scores,args[2],row.names=FALSE)
print(scores,row.names=FALSE,digits=10)
