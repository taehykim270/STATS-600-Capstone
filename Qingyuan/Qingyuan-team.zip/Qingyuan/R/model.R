# Source inherited.R first. Each coefficient is estimated per airport, target
# and horizon, without an intercept. The Fourier climatology supplies the level.
q_grid <- function() {
  methods <- c("ols", "ridge", "ridge", "lasso", "lasso")
  suffix <- c("ols", "ridge03", "ridge30", "lasso03", "lasso15")
  fractions <- c(0, .03, .30, .03, .15)
  groups <- rbind(data.frame(family="none", k=0L),
                  expand.grid(k=1:8, family=c("levels", "changes", "both"),
                              KEEP.OUT.ATTRS=FALSE, stringsAsFactors=FALSE)[,c("family","k")])
  main <- do.call(rbind, lapply(seq_len(nrow(groups)), function(i) {
    family <- groups$family[i]
    k <- groups$k[i]
    data.frame(id=paste0(family, "_k", k, "_", suffix), family=family, k=k,
               method=methods, penalty=fractions, primary=TRUE)
  }))
  extra <- data.frame(
    id=c("both_k4_elastic03", "both_k8_elastic03", "legacy_k8d4_ridge30", "local_day16_ridge30"),
    family=c("both","both","legacy","local_day16"), k=c(4L,8L,8L,4L),
    method=c("elastic","elastic","ridge","ridge"), penalty=c(.03,.03,.30,.30), primary=FALSE)
  rbind(main, extra)
}

q_groups <- function(grid=q_grid()) {
  # These eleven columns, including both pressure gradients, are shared by
  # every design. Keep their historic order for the archived reference fits.
  base <- setdiff(p51_feature_groups()$gradient_pc4, paste0("pc",1:4))
  fields <- function(family, k) {
    levels <- if (k > 0L) paste0("pc",seq_len(k)) else character()
    changes <- if (k > 0L) paste0("dpc",seq_len(k)) else character()
    c(base, switch(family, none=character(), levels=levels, changes=changes,
       both=c(levels,changes), legacy=c(levels,changes[1:4]),
       local_day16=c(levels,changes,paste0("peer_residual",1:12))))
  }
  key <- paste(grid$family, grid$k, sep="_")
  first <- which(!duplicated(key))
  groups <- Map(fields, grid$family[first],grid$k[first])
  setNames(groups, key[first])
}

q_peers <- function(metadata) {
  ranked <- p51_mask_geometry(metadata)$near
  setNames(lapply(TARGET_AIRPORTS,function(airport) {
    near <- ranked[[match(airport,ALL_AIRPORTS)]]
    paste0(head(setdiff(near,airport),12L),"_Mean.TemperatureF")
  }),TARGET_AIRPORTS)
}

# Extend the original training level basis only when additional change axes
# are requested. Columns 9–12 come directly from the archived decomposition.
q_extend_changes <- function(fit,training,d) {
  stopifnot(d>8L, d<=length(fit$pc$sd))
  existing <- 9:min(d,12L)
  extra <- fit$pc12[,existing,drop=FALSE]
  fraction <- fit$pc12_fraction[existing]
  if (d>12L) {
    stations <- rownames(fit$pc12)
    anomalies <- p5_anomalies(training,fit$prep,training$dates,stations)
    z <- p5_standardize(anomalies,fit$pc$center,fit$pc$sd)
    eig <- eigen(crossprod(z),symmetric=TRUE)
    ix <- 13:d
    axes <- eig$vectors[,ix,drop=FALSE]
    pivot <- apply(abs(axes),2L,which.max)
    axes <- sweep(axes,2L,sign(axes[cbind(pivot,seq_along(ix))]),"*")
    axes[!is.finite(fit$pc$sd),] <- 0
    axes[,eig$values[ix]<=max(0,eig$values[1L])*1e-12] <- 0
    dimnames(axes) <- list(stations,paste0("pc",ix))
    total <- sum(pmax(0,eig$values))
    fraction <- c(fraction,if (total>0) pmax(0,eig$values[ix])/total else rep(0,length(ix)))
    extra <- cbind(extra,axes)
  }
  fit$extra_change_axes <- extra
  fit$extra_level_fractions <- fraction
  fit
}

q_design <- function(prepared, peers, block, origins) {
  stopifnot(is.null(block$raw_targets), all(calendar_day(origins) %in% 7:15))
  training <- block$year %in% prepared$prep$train_years
  stopifnot(all(training) || (!any(training) && all(block$day %in% 1:15) &&
                               all(calendar_day(origins)==15L)))
  base <- p51_regression_design(prepared, block, origins)
  old <- dimnames(base$x)[[2L]]
  columns <- c(old, paste0("pc",5:8), paste0("dpc",1:8), paste0("peer_residual",1:12))
  extra_changes <- if (!is.null(prepared$extra_change_axes)) paste0("d",colnames(prepared$extra_change_axes))
  columns <- c(columns,extra_changes)
  x <- array(0, c(length(origins),length(columns),nrow(block$series)),
             dimnames=list(NULL,columns,block$series$column))
  x[,old,] <- base$x
  stations <- rownames(prepared$pc12)
  levels <- p5_anomalies(block,prepared$prep,origins,stations)
  standardized <- p5_standardize(levels,prepared$pc$center,prepared$pc$sd)
  extra_axes <- prepared$pc12[,5:8,drop=FALSE]
  x[,paste0("pc",5:8),] <- standardized %*% extra_axes
  change <- p8_change(prepared,block,origins)
  x[,paste0("dpc",1:4),] <- change$national
  x[,paste0("dpc",5:8),] <- change$z %*% extra_axes
  if (length(extra_changes)) x[,extra_changes,] <- change$z %*% prepared$extra_change_axes
  for (airport in names(peers)) {
    target <- block$series$airport == airport
    x[,paste0("peer_residual",1:12),target] <- change$residual[,peers[[airport]],drop=FALSE]
  }
  list(x=x, base=base$base, coverage=base$coverage)
}

# The optional C accelerator uses exactly the same objective and convergence
# threshold as the base-R solver below. Compile in a private temp directory;
# on a machine without a C compiler all fits still work. Disable explicitly
# with options(qingyuan.native=FALSE). No compiled binary is distributed.
.q_model_path <- tryCatch(normalizePath(sys.frame(1L)$ofile),error=function(e) "")
.q_solver_state <- new.env(parent=emptyenv())
q_native <- function() {
  if (!isTRUE(getOption("qingyuan.native", TRUE))) return(FALSE)
  if (is.loaded("q_coordinate")) return(TRUE)
  if (isTRUE(.q_solver_state$tried)) return(FALSE)
  .q_solver_state$tried <- TRUE
  candidates <- c(file.path(dirname(.q_model_path),"..","src","coordinate.c"),
                  "Qingyuan/src/coordinate.c","src/coordinate.c")
  path <- candidates[file.exists(candidates)][1L]
  if (is.na(path)) return(FALSE)
  build <- tempfile("qingyuan-compiled-")
  dir.create(build)
  source <- file.path(build,"coordinate.c")
  file.copy(path,source)
  library <- file.path(build,paste0("coordinate",.Platform$dynlib.ext))
  r <- file.path(R.home("bin"),"R")
  log <- suppressWarnings(system2(r,c("CMD","SHLIB","-o",shQuote(library),shQuote(source)),
                                  stdout=TRUE,stderr=TRUE))
  if (!file.exists(library)) return(FALSE)
  tryCatch({dyn.load(library); TRUE}, error=function(e) FALSE)
}

# Standardized folds can have different observed target rows at each lead.
# Gram matrices/cross-products are shared only when row masks are identical.
q_penalized <- function(gram,cross,fractions,alpha,native) {
  p <- nrow(gram)
  h <- ncol(cross)
  m <- length(fractions)
  beta <- array(0,c(p,h,m))
  done <- matrix(FALSE,h,m)
  if (native) {
    out <- .C("q_coordinate",as.integer(p),as.integer(h),as.double(gram),as.double(cross),
              as.integer(m),as.double(fractions),as.double(alpha),coef=as.double(beta),
              converged=integer(h*m))
    beta[] <- out$coef
    done[] <- out$converged==1L
  }
  for (j in seq_len(h)) {
    maximum <- max(abs(cross[,j]))
    for (i in which(!done[j,])) {
      l1 <- maximum*fractions[i]
      l2 <- l1*(1-alpha[i])/alpha[i]
      regularized <- gram
      diag(regularized) <- diag(gram)+l2
      start <- if (i>1L && alpha[i]==alpha[i-1L]) beta[,j,i-1L] else numeric(p)
      beta[,j,i] <- p3_lasso_gram(regularized,cross[,j],l1,start)
    }
  }
  beta
}

q_fit_series <- function(x, y, grid, groups, native, group_key=paste(grid$family,grid$k,sep="_")) {
  features <- colnames(x)
  beta <- array(0,c(ncol(x),5L,nrow(grid)),dimnames=list(features,as.character(1:5),grid$id))
  rms <- matrix(0,ncol(x),5L,dimnames=list(features,as.character(1:5)))
  mask <- lapply(1:5,function(h) unname(is.finite(y[,h])))
  by_group <- split(seq_len(nrow(grid)),group_key)
  for (rows in unique(mask)) {
    n <- sum(rows)
    if (!n) next
    horizons <- which(vapply(mask,identical,logical(1L),y=rows))
    raw <- x[rows,,drop=FALSE]
    scale <- sqrt(colMeans(raw^2))
    rms[,horizons] <- scale
    keep <- scale>0
    if (!any(keep)) next
    z <- sweep(raw[,keep,drop=FALSE],2L,scale[keep],"/")
    response <- y[rows,horizons,drop=FALSE]
    all_gram <- crossprod(z)/n
    all_cross <- crossprod(z,response)/n
    for (name in names(groups)) {
      ids <- by_group[[name]]
      use <- intersect(groups[[name]],features[keep])
      if (!length(use)) next
      h <- if (name=="local_day16_4") match(1L,horizons,nomatch=0L) else seq_along(horizons)
      if (!length(h) || !all(h)) next
      gram <- all_gram[use,use,drop=FALSE]
      cross <- all_cross[use,h,drop=FALSE]
      ols <- ids[grid$method[ids]=="ols"]
      if (length(ols)) {
        # Cholesky and QR solve the same LS problem. Use QR on the original
        # design for poorly conditioned or aliased inputs (historical policy).
        ch <- tryCatch(chol(gram),error=function(e) NULL)
        if (is.null(ch) || rcond(ch,triangular=TRUE)<1e-5) {
          b <- matrix(lm.fit(z[,use,drop=FALSE],response[,h,drop=FALSE])$coefficients,
                      nrow=length(use))
          b[is.na(b)] <- 0
        } else {
          b <- backsolve(ch,forwardsolve(t(ch),cross))
        }
        beta[use,horizons[h],ols] <- b/scale[use]
      }
      for (id in ids[grid$method[ids]=="ridge"]) {
        regularized <- gram
        diag(regularized) <- diag(gram)+grid$penalty[id]
        beta[use,horizons[h],id] <- solve(regularized,cross)/scale[use]
      }
      paths <- ids[grid$method[ids] %in% c("lasso","elastic")]
      if (length(paths)) {
        paths <- paths[order(grid$method[paths]=="elastic",-grid$penalty[paths])]
        alpha <- ifelse(grid$method[paths]=="elastic",.5,1)
        b <- q_penalized(gram,cross,grid$penalty[paths],alpha,native)
        beta[use,horizons[h],paths] <- b/as.numeric(scale[use])
      }
    }
  }
  # The last comparator has one distinct regression at lead 1 only.
  if ("local_day16_ridge30" %in% grid$id)
    beta[,2:5,"local_day16_ridge30"] <- beta[,2:5,"both_k4_ridge30"]
  list(coef=beta, rms=rms)
}

q_fit <- function(training,metadata,grid=q_grid(),groups=q_groups(grid),
                  group_key=paste(grid$family,grid$k,sep="_"),max_change_rank=8L) {
  stopifnot(is.null(training$raw_targets))
  years <- sort(unique(training$year))
  prepared <- p6_prepare(training,metadata)
  if (max_change_rank>8L) prepared <- q_extend_changes(prepared,training,max_change_rank)
  peers <- q_peers(metadata)
  origins <- p3_year_origins(training,years,training=TRUE)
  clean <- q_design(prepared,peers,training,origins)
  y <- p3_response_array(training$values,training$dates,origins,training$series$column)-clean$base
  masked <- lapply(1:2,function(i) {
    block <- p51_apply_mask(training,metadata,c(.10,.25)[i],"mixed",i,"training")
    q_design(prepared,peers,block,origins)$x
  })
  stopifnot(!anyDuplicated(grid$id),length(group_key)==nrow(grid),
            setequal(names(groups),unique(group_key)))
  native <- q_native()
  columns <- dimnames(clean$x)[[2L]]
  coef <- array(0,c(length(columns),5L,nrow(grid),nrow(training$series)),
                dimnames=list(columns,as.character(1:5),grid$id,training$series$column))
  rms <- array(0,c(length(columns),5L,nrow(training$series)),
               dimnames=dimnames(coef)[c(1L,2L,4L)])
  for (j in seq_len(nrow(training$series))) {
    x <- rbind(clean$x[,,j],clean$x[,,j],masked[[1L]][,,j],masked[[2L]][,,j])
    response <- y[rep(seq_along(origins),4L),,j]
    fit <- q_fit_series(x,response,grid,groups,native,group_key)
    coef[,,,j] <- fit$coef
    rms[,,j] <- fit$rms
  }
  list(prepared=prepared,peers=peers,coefficients=coef,rms=rms,years=years,grid=grid,
       explained=setNames(cumsum(prepared$pc12_fraction[1:8]),paste0("pc",1:8)))
}

q_predict <- function(fit,context,origins=NULL,ids=NULL) {
  stopifnot(is.null(context$raw_targets),all(context$day %in% 1:15),
            !any(context$year %in% fit$years))
  if (is.null(origins)) origins <- p3_year_origins(context,sort(unique(context$year)))
  stopifnot(length(origins)>0L,!anyDuplicated(origins),all(calendar_day(origins)==15L),
            all(origins %in% context$dates))
  d <- q_design(fit$prepared,fit$peers,context,origins)
  coef <- fit$coefficients
  if (!is.null(ids)) {
    stopifnot(is.character(ids),length(ids)>0L,!anyNA(ids),!anyDuplicated(ids),
              all(ids %in% dimnames(coef)[[3L]]))
    coef <- coef[,,ids,,drop=FALSE]
  }
  stopifnot(identical(dimnames(d$x)[[2L]],dimnames(coef)[[1L]]),
            identical(dimnames(d$x)[[3L]],dimnames(coef)[[4L]]))
  n <- length(origins)
  ids <- dimnames(coef)[[3L]]
  out <- array(0,c(n,5L,nrow(context$series),length(ids)))
  for (j in seq_len(nrow(context$series))) {
    x <- matrix(d$x[,,j],nrow=n)
    forecast <- x %*% matrix(coef[,,,j],nrow=ncol(x))
    out[,,j,] <- as.vector(forecast)+rep(as.vector(d$base[,,j]),length(ids))
  }
  predictions <- matrix(aperm(out,c(3L,2L,1L,4L)),ncol=length(ids),dimnames=list(NULL,ids))
  stopifnot(all(is.finite(predictions)))
  predictions
}
