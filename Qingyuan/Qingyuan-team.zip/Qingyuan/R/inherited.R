# Reused STATS 600 definitions from archive commit 3d75550.
# Source text is retained verbatim. The comments give original file and line spans.
# Only dependencies of the research and prediction entry points are included.

# R/config.R:2-3
TARGET_AIRPORTS <- c("ABQ", "ATL", "BOS", "DEN", "DFW", "DLH", "DTW", "EYW",
                     "IAD", "LAN", "LAX", "SEA", "SFO", "SLC", "TVC")

# R/config.R:4-9
ALL_AIRPORTS <- strsplit(paste(
  "ABQ AIY ALB AMA ATL AUS BFL BHM BIS BMG BNA BOS BTR BUF BWI BZN CHA CHS CLE CLL",
  "CLT CMI COS CRW CVG DEN DFW DLH DSM DTW EKO ELP EUG EYW FAR FLG FLL FNT FOE FSD",
  "GEG GJT GNV GRB GRR HFD HOU IAD ILG IND LAN LAS LAX LCK LGA LIT LNK MAF MCI MCO",
  "MEM MIA MKE MOB MOT MSN MSP MYR OAK OKC OLM OMA ORD PDX PHL PHX PIT PVD RAP RDU",
  "RFD RIC RNO SAN SAT SAV SDF SEA SFO SLC STL SUX TLH TTN TUL TUS TVC UNV"), " ")[[1L]]

# R/config.R:10-11
TARGET_FIELDS <- c(max = "Max.TemperatureF", mean = "Mean.TemperatureF",
                   min = "Min.TemperatureF")

# R/config.R:12-17
WEATHER_FIELDS <- c(unname(TARGET_FIELDS), "Max.Dew.PointF", "MeanDew.PointF",
  "Min.DewpointF", "Max.Humidity", "Mean.Humidity", "Min.Humidity",
  "Max.Sea.Level.PressureIn", "Mean.Sea.Level.PressureIn", "Min.Sea.Level.PressureIn",
  "Max.VisibilityMiles", "Mean.VisibilityMiles", "Min.VisibilityMiles",
  "Max.Wind.SpeedMPH", "Mean.Wind.SpeedMPH", "Max.Gust.SpeedMPH",
  "PrecipitationIn", "CloudCover", "Events", "WindDirDegrees")

# R/config.R:19-19
HISTORY_DATES <- seq(as.Date("2005-01-01"), as.Date("2014-12-31"), by = "day")

# R/config.R:21-21
TEMPERATURE_BOUNDS <- c(-150, 150)

# R/config.R:24-27
assert <- function(ok, message) {
  if (length(ok) != 1L || is.na(ok) || !ok) stop(message, call. = FALSE)
  invisible(TRUE)
}

# R/config.R:29-29
calendar_year <- function(dates) as.integer(format(dates, "%Y"))

# R/config.R:30-30
calendar_month <- function(dates) as.integer(format(dates, "%m"))

# R/config.R:31-31
calendar_day <- function(dates) as.integer(format(dates, "%d"))

# R/config.R:33-38
valid_year <- function(year) {
  assert(is.numeric(year) && length(year) == 1L && is.finite(year) &&
           year == as.integer(year) && year >= 1900 && year <= 9998,
         "year must be one integer between 1900 and 9998")
  as.integer(year)
}

# R/config.R:40-43
target_columns <- function(airports = TARGET_AIRPORTS) {
  unlist(lapply(airports, function(a) paste(a, TARGET_FIELDS, sep = "_")),
         use.names = FALSE)
}

# R/config.R:45-47
prediction_key <- function(x) {
  paste(as.character(x$target_date), x$airport, x$target, sep = "|")
}

# R/data.R:2-16
read_weather <- function(path, historical = FALSE) {
  assert(file.exists(path), paste("Data file does not exist:", path))
  env <- new.env(parent = emptyenv())
  loaded <- load(path, envir = env)
  assert("weather" %in% loaded, "RDA must contain a data.frame named weather")
  values <- env$weather
  assert(is.data.frame(values), "weather must be a data.frame")
  row_dates <- rownames(values)
  assert(all(grepl("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$", row_dates)),
         "Date row names are required; dates must never be inferred by row position")
  dates <- as.Date(row_dates, format = "%Y-%m-%d")
  result <- new_weather(dates, values)
  if (historical) validate_history(result)
  result
}

# R/data.R:18-30
new_weather <- function(dates, values) {
  assert(inherits(dates, "Date"), "dates must have class Date")
  assert(is.data.frame(values), "values must be a data.frame")
  assert(length(dates) == nrow(values), "Date and weather row counts differ")
  assert(!anyNA(dates) && !anyDuplicated(dates), "Dates must be valid and unique")
  assert(length(dates) < 2L || all(diff(dates) > 0), "Dates must be strictly increasing")
  assert(!anyDuplicated(names(values)), "Column names must be unique")
  needed <- target_columns()
  assert(all(needed %in% names(values)), "Missing one or more required temperature columns")
  assert(all(vapply(values[needed], is.numeric, logical(1))),
         "Target temperatures must be numeric, never factor codes")
  structure(list(dates = dates, values = values), class = "weather_data")
}

# R/data.R:32-39
validate_history <- function(data) {
  assert(length(data$dates) == length(HISTORY_DATES) && all(data$dates == HISTORY_DATES),
         "Historical data must contain every date from 2005-01-01 through 2014-12-31")
  expected <- unlist(lapply(ALL_AIRPORTS, function(a) paste(a, WEATHER_FIELDS, sep = "_")))
  assert(ncol(data$values) == 2156L && setequal(names(data$values), expected),
         "Historical schema must contain the 98 airports and 22 documented fields")
  invisible(TRUE)
}

# R/data.R:41-45
subset_weather <- function(data, keep) {
  assert(is.logical(keep) && length(keep) == length(data$dates) && !anyNA(keep),
         "Row selection must be a complete logical mask")
  new_weather(data$dates[keep], data$values[keep, , drop = FALSE])
}

# R/data.R:49-83
temperature_panel <- function(data, airports = TARGET_AIRPORTS) {
  needed <- target_columns(airports)
  assert(all(needed %in% names(data$values)), "Missing requested airport temperatures")
  n <- length(data$dates)
  parts <- lapply(airports, function(airport) {
    raw <- as.matrix(data$values[paste(airport, TARGET_FIELDS, sep = "_")])
    storage.mode(raw) <- "double"
    reason <- matrix("ok", nrow = n, ncol = 3L)
    reason[is.na(raw)] <- "missing"
    reason[is.infinite(raw)] <- "nonfinite"
    reason[is.finite(raw) & (raw < TEMPERATURE_BOUNDS[1] |
                            raw > TEMPERATURE_BOUNDS[2])] <- "outside_fixed_bounds"
    cleaned <- raw
    cleaned[reason != "ok"] <- NA_real_
    # Check every known pair, even when one component is missing.
    inconsistent <- (cleaned[, 1] < cleaned[, 2]) |
      (cleaned[, 2] < cleaned[, 3]) | (cleaned[, 1] < cleaned[, 3])
    inconsistent[is.na(inconsistent)] <- FALSE
    if (any(inconsistent)) {
      mask <- matrix(inconsistent, nrow = n, ncol = 3L) & reason == "ok"
      reason[mask] <- "inconsistent_triplet"
      cleaned[mask] <- NA_real_
    }
    data.frame(date = rep(data$dates, 3L), airport = rep(airport, 3L * n),
      target = rep(names(TARGET_FIELDS), each = n), raw_value = as.vector(raw),
      value = as.vector(cleaned), quality = as.vector(reason),
      stringsAsFactors = FALSE)
  })
  out <- do.call(rbind, parts)
  rownames(out) <- NULL
  out$year <- calendar_year(out$date)
  out$month <- calendar_month(out$date)
  out$day <- calendar_day(out$date)
  out
}

# R/data.R:101-113
forecast_grid <- function(year, months = 1:12) {
  year <- valid_year(year)
  assert(is.numeric(months) && length(months) > 0L && !anyNA(months) &&
           !anyDuplicated(months) && all(months %in% 1:12), "Invalid forecast months")
  out <- expand.grid(target = names(TARGET_FIELDS), airport = TARGET_AIRPORTS,
    horizon = 1:5, month = sort(months), stringsAsFactors = FALSE)
  out$year <- year
  out$origin_date <- as.Date(sprintf("%04d-%02d-15", year, out$month))
  out$target_date <- out$origin_date + out$horizon
  out <- out[c("year", "month", "origin_date", "target_date", "horizon", "airport", "target")]
  rownames(out) <- NULL
  out
}

# R/phase2_ar.R:20-25
phase2_series <- function() {
  series <- expand.grid(target = names(TARGET_FIELDS), airport = TARGET_AIRPORTS,
                        stringsAsFactors = FALSE)
  series$column <- paste(series$airport, TARGET_FIELDS[series$target], sep = "_")
  series
}

# R/phase3_features.R:5-25
p3_neighbors <- function(metadata) {
  if (is.character(metadata) && length(metadata) == 1L) {
    metadata <- read.csv(metadata, stringsAsFactors = FALSE)
  }
  assert(all(c("airport", "latitude", "longitude") %in% names(metadata)), "Missing airport coordinates")
  assert(!anyDuplicated(metadata$airport) && setequal(metadata$airport, ALL_AIRPORTS),
         "Expected one coordinate record for each of the 98 airports")
  assert(all(is.finite(metadata$latitude) & abs(metadata$latitude) <= 90) &&
         all(is.finite(metadata$longitude) & abs(metadata$longitude) <= 180), "Invalid airport geometry")
  lat <- metadata$latitude * pi / 180
  lon <- metadata$longitude * pi / 180
  selected <- lapply(TARGET_AIRPORTS, function(a) {
    j <- match(a, metadata$airport)
    hav <- sin((lat - lat[j]) / 2)^2 + cos(lat[j]) * cos(lat) * sin((lon - lon[j]) / 2)^2
    km <- 2 * 6371 * asin(sqrt(pmin(1, pmax(0, hav))))
    km[j] <- Inf
    peers <- head(order(km, metadata$airport), 2L)
    data.frame(airport = a, rank = 1:2, peer = metadata$airport[peers], distance_km = km[peers])
  })
  do.call(rbind, selected)
}

# R/phase3_features.R:29-48
p3_weather_mean <- function(data, airports, field) {
  columns <- paste(airports, paste0("Mean.", field), sep = "_")
  values <- matrix(NA_real_, length(data$dates), length(airports), dimnames = list(NULL, columns))
  for (j in seq_along(airports)) {
    triplet <- paste(c("Max", "Mean", "Min"), field, sep = ".")
    names_j <- paste(airports[j], triplet, sep = "_")
    block <- data$values[names_j]
    assert(all(vapply(block, is.numeric, logical(1))), "Weather QC requires numeric measurements")
    block <- as.matrix(block)
    valid <- is.finite(block)
    if (field == "Humidity") valid <- valid & block >= 0 & block <= 100
    else valid <- valid & block > 0
    block[!valid] <- NA_real_
    reversed <- (block[, 1] < block[, 2]) | (block[, 2] < block[, 3]) | (block[, 1] < block[, 3])
    result <- block[, 2]
    result[which(reversed)] <- NA_real_
    values[, j] <- result
  }
  values
}

# R/phase3_features.R:53-75
p3_raw <- function(data, neighbors) {
  series <- phase2_series()
  assert(all(c("airport", "rank", "peer") %in% names(neighbors)), "Missing neighbor mapping")
  expected <- expand.grid(airport = TARGET_AIRPORTS, rank = 1:2, stringsAsFactors = FALSE)
  key <- function(x) paste(x$airport, x$rank)
  assert(nrow(neighbors) == nrow(expected) && setequal(key(neighbors), key(expected)) &&
         all(neighbors$airport != neighbors$peer) && all(neighbors$peer %in% ALL_AIRPORTS) &&
         !anyDuplicated(neighbors[c("airport", "peer")]), "Each airport needs two distinct other peers")
  selected <- unique(c(TARGET_AIRPORTS, neighbors$peer))
  assert(all(vapply(data$values[target_columns(selected)], is.numeric, logical(1))),
         "Temperature QC requires numeric measurements")
  temperatures <- temperature_panel(data, airports = selected)
  temp_columns <- target_columns(selected)
  values <- matrix(NA_real_, length(data$dates), length(temp_columns), dimnames = list(NULL, temp_columns))
  position <- cbind(match(temperatures$date, data$dates),
                    match(paste(temperatures$airport, TARGET_FIELDS[temperatures$target], sep = "_"), temp_columns))
  values[position] <- temperatures$value
  values <- cbind(values, p3_weather_mean(data, TARGET_AIRPORTS, "Sea.Level.PressureIn"),
                  p3_weather_mean(data, TARGET_AIRPORTS, "Humidity"))
  list(dates = data$dates, year = calendar_year(data$dates), month = calendar_month(data$dates),
       day = calendar_day(data$dates), series = series, neighbors = neighbors, values = values,
       raw_targets = as.matrix(data$values[series$column]))
}

# R/phase3_features.R:80-101
p3_preprocess <- function(raw, train_years) {
  train_years <- sort(unique(train_years))
  assert(length(train_years) > 0L && all(train_years %in% raw$year), "Unknown or empty training-year set")
  use <- raw$year %in% train_years
  values <- raw$values[use, , drop = FALSE]
  months <- raw$month[use]
  annual_n <- colSums(is.finite(values))
  annual_mean <- colMeans(values, na.rm = TRUE)
  assert(all(annual_n[raw$series$column] > 0), "Target climatology unavailable in training years")
  annual_mean[annual_n == 0] <- 0
  centers <- matrix(NA_real_, 12L, ncol(values), dimnames = list(as.character(1:12), colnames(values)))
  monthly_n <- centers
  for (m in 1:12) {
    group <- values[months == m, , drop = FALSE]
    centers[m, ] <- colMeans(group, na.rm = TRUE)
    monthly_n[m, ] <- colSums(is.finite(group))
    fallback <- monthly_n[m, ] == 0
    centers[m, fallback] <- annual_mean[fallback]
  }
  list(train_years = train_years, centers = centers, monthly_n = monthly_n, annual_n = annual_n,
       neighbors = raw$neighbors)
}

# R/phase3_features.R:103-108
p3_response_array <- function(values, dates, origins, columns) {
  out <- array(NA_real_, c(length(origins), 5L, length(columns)),
               dimnames = list(NULL, as.character(1:5), columns))
  for (h in 1:5) out[, h, ] <- values[match(origins + h, dates), columns, drop = FALSE]
  out
}

# R/phase3_features.R:110-113
p3_truth <- function(raw, origins) {
  assert(inherits(origins, "Date") && all(calendar_day(origins) == 15), "Score only day-15 origins")
  p3_response_array(raw$raw_targets, raw$dates, origins, raw$series$column)
}

# R/phase3_fit.R:6-30
p3_candidate_grid <- function(groups, ridge = P3_RIDGE, lasso = P3_LASSO) {
  if (!is.list(groups) || !length(groups) || is.null(names(groups)) ||
      anyNA(names(groups)) || any(!nzchar(names(groups))) || anyDuplicated(names(groups))) {
    stop("Feature groups must be a nonempty named list with unique names")
  }
  for (features in groups) {
    if (!is.character(features) || !length(features) || anyNA(features) ||
        any(!nzchar(features)) || anyDuplicated(features)) stop("Invalid feature group")
  }
  for (lambda in list(ridge, lasso)) {
    if (!is.numeric(lambda) || any(!is.finite(lambda)) || any(lambda <= 0) ||
        anyDuplicated(lambda)) stop("Penalty grid values must be unique, positive and finite")
  }
  if (any(lasso > 1)) stop("Lasso penalties are fractions of the training lambda maximum")
  number <- function(x) vapply(x, function(v) format(v, digits = 12L, scientific = FALSE, trim = TRUE), "")
  names_for <- function(method, numbers) {
    if (length(numbers)) paste0(method, "_", number(numbers)) else character()
  }
  variant <- c("ols", names_for("ridge", ridge), names_for("lasso", lasso))
  do.call(rbind, unname(lapply(names(groups), function(group) {
    data.frame(id = paste(group, variant, sep = "__"), group = group,
               method = c("ols", rep("ridge", length(ridge)), rep("lasso", length(lasso))),
               lambda = c(0, ridge, lasso), stringsAsFactors = FALSE)
  })))
}

# R/phase3_fit.R:34-40
p3_lasso_kkt <- function(beta, gram, cross, penalty) {
  residual <- cross - drop(gram %*% beta)
  active <- beta != 0
  violations <- pmax(abs(residual) - penalty, 0)
  violations[active] <- abs(residual[active] - penalty * sign(beta[active]))
  max(violations)
}

# R/phase3_fit.R:42-72
p3_lasso_gram <- function(gram, cross, penalty, start) {
  beta <- as.numeric(start)
  if (max(abs(cross)) <= penalty) return(numeric(length(beta)))
  tolerance <- 1e-8 * max(1, max(abs(cross)))
  diagonal <- diag(gram)
  # Once the active signs stabilize, solve their linear equations jointly.
  # This accelerates convergence for nearby airports with correlated weather.
  # Cyclic coordinate updates handle intermediate sign changes and singular sets.
  last_sign <- rep(NA_real_, length(beta))
  for (iteration in seq_len(20000L)) {
    for (j in seq_along(beta)) {
      partial <- cross[j] - sum(gram[, j] * beta) + diagonal[j] * beta[j]
      beta[j] <- sign(partial) * max(abs(partial) - penalty, 0) / diagonal[j]
    }
    if (p3_lasso_kkt(beta, gram, cross, penalty) <= tolerance) return(beta)
    signs <- sign(beta)
    if (!identical(signs, last_sign)) {
      active <- which(signs != 0)
      gram_active <- gram[active, active, drop = FALSE]
      proposed <- tryCatch(as.numeric(solve(gram_active, cross[active] - penalty * signs[active])),
                           error = function(e) NULL)
      if (length(proposed) == length(active) && all(is.finite(proposed)) &&
          all(sign(proposed) == signs[active])) {
        beta[active] <- proposed
        if (p3_lasso_kkt(beta, gram, cross, penalty) <= tolerance) return(beta)
      }
      last_sign <- signs
    }
  }
  stop("Lasso fit failed the training KKT convergence check")
}

# R/phase3_fit.R:74-156
p3_fit_predict <- function(x_train, y_train, x_valid, groups,
                           ridge = P3_RIDGE, lasso = P3_LASSO) {
  # The caller builds these matrices after fitting monthly climatologies on
  # the current training years. Train and valid X contain zero for missing anomalies.
  for (x in list(x_train, y_train, x_valid)) {
    if (!is.matrix(x) || !is.numeric(x)) stop("Supply numeric matrices for training X, Y and validation X")
  }
  features <- colnames(x_train)
  if (is.null(features) || anyNA(features) || any(!nzchar(features)) || anyDuplicated(features) ||
      !identical(colnames(x_valid), features) || nrow(x_train) != nrow(y_train) ||
      !nrow(x_train) || ncol(y_train) != 5L || !all(is.finite(x_train)) || !all(is.finite(x_valid))) {
    stop("Require aligned, named finite feature matrices and five training response horizons")
  }
  candidates <- p3_candidate_grid(groups, ridge, lasso)
  if (!all(unlist(groups, use.names = FALSE) %in% features)) stop("Unknown feature in candidate group")

  horizons <- as.character(1:5)
  beta <- array(0, dim = c(length(features), 5L, nrow(candidates)),
                dimnames = list(features, horizons, candidates$id))
  rms <- matrix(0, length(features), 5L, dimnames = list(features, horizons))
  penalty_used <- matrix(0, 5L, nrow(candidates), dimnames = list(horizons, candidates$id))
  valid_y <- is.finite(y_train)
  n_train <- colSums(valid_y)

  # Most horizons share the exact same training rows. Share the standardized
  # design and Gram matrix across these horizons while keeping their losses distinct.
  masks <- lapply(seq_len(5L), function(h) unname(valid_y[, h]))
  for (rows in unique(masks)) {
    count <- sum(rows)
    if (count == 0L) next
    h <- which(vapply(masks, identical, logical(1L), y = rows))
    raw <- x_train[rows, , drop = FALSE]
    scale <- sqrt(colMeans(raw^2))
    rms[, h] <- scale
    # A zero-energy input has no training signal. Keep its coefficient at zero.
    keep <- scale > 0
    if (!any(keep)) next
    standardized <- sweep(raw[, keep, drop = FALSE], 2L, scale[keep], "/")
    response <- y_train[rows, h, drop = FALSE]
    full_gram <- crossprod(standardized) / count
    full_cross <- crossprod(standardized, response) / count

    for (group in names(groups)) {
      ix <- intersect(groups[[group]], features[keep])
      if (!length(ix)) next
      gram <- full_gram[ix, ix, drop = FALSE]
      cross <- full_cross[ix, , drop = FALSE]
      group_ids <- which(candidates$group == group)
      ols_id <- group_ids[candidates$method[group_ids] == "ols"]
      # QR handles aliased predictors and matches the existing Phase 2 LS fit.
      ols <- matrix(lm.fit(standardized[, ix, drop = FALSE], response)$coefficients,
                    nrow = length(ix), ncol = length(h))
      ols[is.na(ols)] <- 0
      beta[ix, h, ols_id] <- ols / scale[ix]

      for (id in group_ids[candidates$method[group_ids] == "ridge"]) {
        penalty <- candidates$lambda[id]
        regularized_gram <- gram
        diag(regularized_gram) <- diag(gram) + penalty
        beta[ix, h, id] <- solve(regularized_gram, cross) / scale[ix]
        penalty_used[h, id] <- penalty
      }
      lasso_ids <- group_ids[candidates$method[group_ids] == "lasso"]
      lasso_ids <- lasso_ids[order(candidates$lambda[lasso_ids], decreasing = TRUE)]
      for (column in seq_along(h)) {
        cross_y <- as.numeric(cross[, column])
        lambda_max <- max(abs(cross_y))
        fit <- numeric(length(ix))
        for (id in lasso_ids) {
          penalty <- candidates$lambda[id] * lambda_max
          fit <- p3_lasso_gram(gram, cross_y, penalty, start = fit)
          beta[ix, h[column], id] <- fit / scale[ix]
          penalty_used[h[column], id] <- penalty
        }
      }
    }
  }
  forecasts <- x_valid %*% matrix(beta, nrow = length(features))
  predictions <- array(forecasts, dim = c(nrow(x_valid), 5L, nrow(candidates)),
                       dimnames = list(rownames(x_valid), horizons, candidates$id))
  list(predictions = predictions, coefficients = beta, candidate_grid = candidates,
       n_train = n_train, scale = rms, penalty_used = penalty_used)
}

# R/phase3_backtest.R:2-9
p3_groups <- function() {
  local <- c('lag1', 'lag2')
  one <- c(local, 'peer1_lag1', 'peer1_lag2')
  spatial <- c(one, 'peer2_lag1', 'peer2_lag2')
  list(local=local, neighbor1=one, spatial=spatial,
       pressure=c(spatial, 'pressure', 'pressure_change'), humidity=c(spatial, 'humidity'),
       weather=c(spatial, 'pressure', 'pressure_change', 'humidity'))
}

# R/phase3_backtest.R:11-14
p3_year_origins <- function(raw, years, training=FALSE) {
  days <- if (training) 7:15 else 15L
  raw$dates[raw$year %in% years & raw$day %in% days]
}

# R/phase3_backtest.R:47-47
p3_truth_vector <- function(raw, origins) as.vector(aperm(p3_truth(raw, origins), c(3,2,1)))

# R/phase4_order.R:3-42
p4_order_forecasts <- function(forecasts, year) {
  grid <- forecast_grid(year)
  assert(is.data.frame(forecasts) && all(c(names(grid),'prediction','model') %in% names(forecasts)),
         'Missing forecast columns')
  assert(nrow(forecasts)==nrow(grid) && is.numeric(forecasts$prediction) &&
         all(is.finite(forecasts$prediction)), 'Expected 2700 finite forecasts')
  assert(is.character(forecasts$model) && !anyNA(forecasts$model) &&
         length(unique(forecasts$model))==1L && nzchar(forecasts$model[1]),
         'Expected one named model')
  keys <- prediction_key(forecasts)
  index <- match(keys,prediction_key(grid))
  assert(!anyDuplicated(keys) && !anyNA(index), 'Missing, duplicate or unexpected forecast keys')
  for (field in names(grid)) {
    assert(identical(as.character(forecasts[[field]]),as.character(grid[[field]][index])),
           paste('Forecast calendar mismatch for',field))
  }

  # Align each statistic by the validated canonical grid, then update the same
  # original row indices, even when the three components were not contiguous.
  index_by_stat <- vapply(c('min','mean','max'),function(stat) {
    match(prediction_key(grid[grid$target==stat,]),keys)
  }, integer(nrow(grid)/3L))
  values <- matrix(forecasts$prediction[index_by_stat], ncol=3L)
  inversions <- which(values[,1] > values[,2] | values[,2] > values[,3])
  for(i in inversions) {
    # Pool adjacent violating blocks. If the pooled pair respects the third
    # value, write only that pair, preserving the singleton bit for bit.
    v <- values[i,]
    pair <- if(v[1L]>v[2L]) 1:2 else 2:3
    average <- mean(v[pair])
    crosses_singleton <- if(pair[1L]==1L) average>v[3L] else v[1L]>average
    if(crosses_singleton) {
      forecasts$prediction[index_by_stat[i,]] <- mean(v)
    } else {
      forecasts$prediction[index_by_stat[i,pair]] <- average
    }
  }
  if(!endsWith(forecasts$model[1],'_isotonic')) forecasts$model <- paste0(forecasts$model,'_isotonic')
  forecasts
}

# R/phase45_features.R:3-3
P45_CALENDAR <- seq(as.Date("2000-01-01"), as.Date("2000-12-31"), by = "day")

# R/phase45_features.R:4-13
P45_BASIS <- local({
  day <- seq_along(P45_CALENDAR) - 1L
  day[60] <- 58.5
  day[61:366] <- day[61:366] - 1L
  angle <- 2 * pi * day / 365
  basis <- cbind(intercept = 1, cos1 = cos(angle), sin1 = sin(angle),
                 cos2 = cos(2 * angle), sin2 = sin(2 * angle))
  rownames(basis) <- format(P45_CALENDAR, "%m-%d")
  basis
})

# R/phase45_features.R:19-19
p45_calendar_index <- function(dates) match(format(dates, "%m-%d"), rownames(P45_BASIS))

# R/phase45_features.R:21-59
p45_raw <- function(data, neighbors) {
  raw <- p3_raw(data, neighbors)
  extras <- lapply(TARGET_AIRPORTS, function(airport) {
    fields <- c("Max.Dew.PointF", "MeanDew.PointF", "Min.DewpointF",
                "Mean.Wind.SpeedMPH", "Max.Wind.SpeedMPH", "WindDirDegrees")
    columns <- paste(airport, fields, sep = "_")
    assert(all(columns %in% names(data$values)), "Missing dew-point or wind columns")
    block <- data$values[columns]
    assert(all(vapply(block, is.numeric, logical(1))), "Dew point, wind speed and direction must be numeric")

    # The audit's fixed broad temperature guard applies to dew-point summaries.
    # A direction of 360 is equivalent to north. Calm has no direction.
    dew <- as.matrix(block[1:3])
    dew[!is.finite(dew) | dew < -150 | dew > 150] <- NA_real_
    reversed <- (dew[, 1] < dew[, 2]) | (dew[, 2] < dew[, 3]) | (dew[, 1] < dew[, 3])
    mean_dew <- dew[, 2]
    mean_dew[which(reversed)] <- NA_real_

    speed <- block[[4]]
    maximum <- block[[5]]
    speed[!is.finite(speed) | speed < 0 | speed > 400] <- NA_real_
    known_maximum <- is.finite(maximum) & maximum >= 0 & maximum <= 400
    speed[which(known_maximum & speed > maximum)] <- NA_real_
    direction <- block[[6]]
    direction[!is.finite(direction) | direction < 0 | direction > 360] <- NA_real_
    radians <- (direction %% 360) * pi / 180
    # Meteorological direction is FROM. Speed and direction are daily
    # summaries, so their product approximates a daily flow vector.
    east <- -speed * sin(radians)
    north <- -speed * cos(radians)
    calm <- which(speed == 0)
    east[calm] <- north[calm] <- 0
    values <- cbind(mean_dew, east, north)
    colnames(values) <- paste(airport, c("MeanDew.PointF", "WindEast", "WindNorth"), sep = "_")
    values
  })
  raw$values <- cbind(raw$values, do.call(cbind, extras))
  raw
}

# R/phase45_features.R:61-89
p45_preprocess <- function(raw, train_years, seasonal) {
  assert(length(seasonal) == 1L && seasonal %in% c("monthly", "fourier"), "Unknown seasonal model")
  if (seasonal == "monthly") {
    prep <- p3_preprocess(raw, train_years)
    prep$seasonal <- seasonal
    return(prep)
  }

  train_years <- sort(unique(train_years))
  assert(length(train_years) > 0L && all(train_years %in% raw$year), "Unknown or empty training-year set")
  use <- raw$year %in% train_years
  values <- raw$values[use, , drop = FALSE]
  basis <- P45_BASIS[p45_calendar_index(raw$dates[use]), , drop = FALSE]
  counts <- colSums(is.finite(values))
  assert(all(counts[raw$series$column] > 0), "Target climatology unavailable in training years")
  coefficients <- matrix(0, ncol(basis), ncol(values),
                         dimnames = list(colnames(basis), colnames(values)))
  for (j in which(counts > 0)) {
    observed <- is.finite(values[, j])
    response <- values[observed, j]
    coefficients["intercept", j] <- mean(response)
    if (length(response) >= ncol(basis)) {
      fit <- lm.fit(basis[observed, , drop = FALSE], response)
      if (fit$rank == ncol(basis)) coefficients[, j] <- fit$coefficients
    }
  }
  list(train_years = train_years, seasonal = seasonal, centers = P45_BASIS %*% coefficients,
       coefficients = coefficients, annual_n = counts, neighbors = raw$neighbors)
}

# R/phase45_fit.R:2-11
p45_groups <- function() {
  local <- p3_groups()$local
  spatial <- c(p3_groups()$spatial, 'pressure')
  list(monthly_local=local, fourier_local=local, monthly_pressure=spatial,
       fourier_pressure=spatial, fourier_dew=c(spatial,'dew'),
       fourier_temp_season=c(spatial,'temp_cos','temp_sin'),
       fourier_pressure_season=c(spatial,'pressure_cos','pressure_sin'),
       fourier_wind=c(spatial,'wind_east','wind_north'),
       fourier_dew_wind=c(spatial,'dew','wind_east','wind_north'))
}

# R/phase45_fit.R:14-24
p45_subset <- function(raw, mask, keep_truth=FALSE) {
  stopifnot(is.logical(mask), length(mask)==length(raw$dates), !anyNA(mask), any(mask))
  result <- list(dates=raw$dates[mask], year=raw$year[mask], month=raw$month[mask],
                 day=raw$day[mask], values=raw$values[mask,,drop=FALSE],
                 neighbors=raw$neighbors, series=raw$series)
  if (keep_truth) {
    stopifnot(is.matrix(raw$raw_targets))
    result$raw_targets <- raw$raw_targets[mask,,drop=FALSE]
  }
  result
}

# R/phase5_region.R:3-26
p5_pressure_geometry <- function(metadata) {
  if (is.character(metadata) && length(metadata) == 1L) {
    metadata <- read.csv(metadata, stringsAsFactors = FALSE)
  }
  stopifnot(!anyDuplicated(metadata$airport), setequal(metadata$airport, ALL_AIRPORTS),
            all(is.finite(metadata$latitude)), all(abs(metadata$latitude) <= 90),
            all(is.finite(metadata$longitude)), all(abs(metadata$longitude) <= 180))
  lat <- metadata$latitude * pi / 180
  lon <- metadata$longitude * pi / 180
  geometry <- lapply(TARGET_AIRPORTS, function(airport) {
    j <- match(airport, metadata$airport)
    delta_lon <- lon - lon[j]
    hav <- sin((lat - lat[j]) / 2)^2 + cos(lat[j]) * cos(lat) * sin(delta_lon / 2)^2
    distance <- 2 * 6371 * asin(sqrt(pmin(1, pmax(0, hav))))
    angle <- atan2(sin(delta_lon) * cos(lat),
                   cos(lat[j]) * sin(lat) - sin(lat[j]) * cos(lat) * cos(delta_lon))
    peers <- setdiff(order(distance, metadata$airport), j)[1:5]
    rows <- c(j, peers)
    data.frame(station = metadata$airport[rows], distance_km = distance[rows],
               east = distance[rows] * sin(angle[rows]) / 100,
               north = distance[rows] * cos(angle[rows]) / 100)
  })
  setNames(geometry, TARGET_AIRPORTS)
}

# R/phase5_region.R:28-49
p5_raw <- function(data, neighbors, metadata = 'outputs/comprehensive_audit/airport_metadata.csv') {
  raw <- p45_raw(data, neighbors)
  geometry <- p5_pressure_geometry(metadata)
  # The neighbor table is preserved by p45_subset and p45_preprocess. Attach
  # immutable geometry there to keep forecast-only and training schemas aligned.
  attr(raw$neighbors, 'pressure_geometry') <- geometry

  local_temp <- paste0(ALL_AIRPORTS, '_Mean.TemperatureF')
  missing_temp <- ALL_AIRPORTS[!local_temp %in% colnames(raw$values)]
  temp <- vapply(missing_temp, function(a) {
    panel <- temperature_panel(data, a)
    panel$value[panel$target == 'mean']
  }, numeric(length(raw$dates)))
  temp <- matrix(temp, nrow = length(raw$dates),
                 dimnames = list(NULL, paste0(missing_temp, '_Mean.TemperatureF')))
  used <- unique(unlist(lapply(geometry, function(x) x$station), use.names = FALSE))
  add_pressure <- setdiff(used, TARGET_AIRPORTS)
  pressure <- p3_weather_mean(data, add_pressure, 'Sea.Level.PressureIn')
  raw$values <- cbind(raw$values, temp, pressure)
  stopifnot(!anyDuplicated(colnames(raw$values)))
  raw
}

# R/phase5_region.R:54-75
p5_pressure_slopes <- function(values, geometry) {
  xy <- as.matrix(geometry[c('east','north')])
  stopifnot(ncol(values) == nrow(xy), ncol(values) <= 6L)
  observed <- is.finite(values)
  masks <- drop(observed %*% 2^(seq_len(ncol(values)) - 1L))
  result <- matrix(0, nrow(values), 2L, dimnames = list(NULL, c('grad_east','grad_north')))
  supported <- logical(nrow(values))
  for (mask in unique(masks)) {
    rows <- which(masks == mask)
    keep <- observed[rows[1L], ]
    if (sum(keep) < 4L) next
    centered <- scale(xy[keep, , drop = FALSE], center = TRUE, scale = FALSE)
    singular <- svd(centered, nu = 0, nv = 0)$d
    if (singular[1L] == 0 || singular[2L] < 0.10 * singular[1L]) next
    plane <- cbind(intercept = 1, centered)
    coefficients <- qr.coef(qr(plane), t(values[rows, keep, drop = FALSE]))
    result[rows, ] <- t(coefficients[2:3, , drop = FALSE])
    supported[rows] <- TRUE
  }
  attr(result, 'supported') <- supported
  result
}

# R/phase5_region.R:77-83
p5_anomalies <- function(raw, prep, dates, columns) {
  rows <- match(dates, raw$dates)
  anomaly <- raw$values[rows, columns, drop = FALSE] -
    prep$centers[p45_calendar_index(dates), columns, drop = FALSE]
  anomaly[, prep$annual_n[columns] == 0L] <- NA_real_
  anomaly
}

# R/phase5_region.R:87-91
p5_standardize <- function(x, center, sd) {
  z <- sweep(sweep(x, 2L, center, '-'), 2L, sd, '/')
  z[!is.finite(z)] <- 0
  z
}

# R/phase5_region.R:93-115
p5_fit_pc <- function(training) {
  count <- colSums(is.finite(training))
  center <- colMeans(training, na.rm = TRUE)
  centered <- sweep(training, 2L, center, '-')
  spread <- sqrt(colSums(centered^2, na.rm = TRUE) / pmax(1, count - 1L))
  supported <- count >= 2L & is.finite(spread) & spread > sqrt(.Machine$double.eps)
  center[!supported] <- 0
  spread[!supported] <- Inf
  z <- p5_standardize(training, center, spread)
  decomposition <- eigen(crossprod(z), symmetric = TRUE)
  loadings <- decomposition$vectors[, 1:4, drop = FALSE]
  # Orient signs by the first maximum-amplitude loading; zero-rank directions
  # carry no information even if a held-out vector happens to project there.
  pivots <- apply(abs(loadings), 2L, which.max)
  loadings <- sweep(loadings, 2L, sign(loadings[cbind(pivots, 1:4)]), '*')
  usable <- decomposition$values[1:4] > max(0, decomposition$values[1L]) * 1e-12
  loadings[, !usable] <- 0
  loadings[!supported, ] <- 0
  dimnames(loadings) <- list(colnames(training), paste0('pc', 1:4))
  total <- sum(pmax(0, decomposition$values))
  fraction <- if (total > 0) pmax(0, decomposition$values[1:4]) / total else rep(0, 4)
  list(center = center, sd = spread, loadings = loadings, variance_fraction = fraction)
}

# R/phase51_masks.R:3-3
P51_MASK_CACHE <- new.env(parent=emptyenv())

# R/phase51_masks.R:4-20
p51_mask_geometry <- function(metadata) {
  ids <- ALL_AIRPORTS
  geo <- metadata[match(ids,metadata$airport),c("airport","latitude","longitude")]
  stopifnot(!anyNA(geo),!anyDuplicated(geo$airport),identical(geo$airport,ids))
  if (!identical(P51_MASK_CACHE$coordinates,geo)) {
    radians <- pi/180
    lat <- geo$latitude*radians
    lon <- geo$longitude*radians
    distance <- sin(outer(lat,lat,"-")/2)^2 + outer(cos(lat),cos(lat))*sin(outer(lon,lon,"-")/2)^2
    by_distance <- lapply(seq_along(ids),function(i) ids[order(distance[i,],ids)])
    remote <- setdiff(ids,unique(c(TARGET_AIRPORTS,p3_neighbors(metadata)$peer)))
    P51_MASK_CACHE$geometry <- list(near=by_distance,remote=remote)
    P51_MASK_CACHE$ranks <- new.env(parent=emptyenv())
    P51_MASK_CACHE$coordinates <- geo
  }
  P51_MASK_CACHE$geometry
}

# R/phase51_masks.R:22-43
p51_rank <- function(metadata,year,month,pattern,replicate,stream) {
  geometry <- p51_mask_geometry(metadata)
  if (pattern=="mixed") pattern <- c("random","cluster")[1L+(month+replicate)%%2L]
  s <- match(stream,c("training","inner","outer"))
  p <- match(pattern,c("random","cluster","remote"))
  stopifnot(!is.na(s),!is.na(p),replicate>=1L,replicate<=99L,month %in% 1:12)
  seed <- as.integer(s*100000000L+p*20000000L+replicate*120000L+year*12L+month)
  key <- as.character(seed)
  ranks <- P51_MASK_CACHE$ranks
  if (!exists(key,ranks,inherits=FALSE)) {
    # Keep RNG state of unrelated callers unchanged.
    old <- get0(".Random.seed",.GlobalEnv,inherits=FALSE)
    on.exit(if (is.null(old)) rm(".Random.seed",envir=.GlobalEnv) else
      assign(".Random.seed",old,envir=.GlobalEnv))
    set.seed(seed,kind="Mersenne-Twister",normal.kind="Inversion",sample.kind="Rejection")
    ids <- if (pattern=="remote") geometry$remote else ALL_AIRPORTS
    rank <- if (pattern=="cluster") geometry$near[[sample.int(length(ids),1L)]] else
      ids[sample.int(length(ids))]
    assign(key,rank,ranks)
  }
  get(key,ranks,inherits=FALSE)
}

# R/phase51_masks.R:45-60
p51_apply_mask <- function(raw,metadata,fraction,pattern,replicate,stream) {
  n <- as.integer(round(fraction*length(ALL_AIRPORTS)))
  if (!n) return(raw)
  periods <- split(seq_along(raw$dates),raw$year*100L+raw$month)
  station <- sub("_.*$","",colnames(raw$values))
  for (rows in periods) {
    i <- rows[1L]
    ranked <- p51_rank(metadata,raw$year[i],raw$month[i],pattern,replicate,stream)
    stopifnot(n>0L,n<=length(ranked))
    missing <- ranked[seq_len(n)]
    columns <- if (pattern=="remote") match(paste0(missing,"_Mean.TemperatureF"),colnames(raw$values)) else
      which(station %in% missing)
    raw$values[rows,columns] <- NA_real_
  }
  raw
}

# R/phase51_masks.R:62-74
p51_scenarios <- function() {
  scenarios <- list(data.frame(pattern="original",missing=0L,replicate=1L,weight=.50))
  for (pattern in c("random","cluster","remote")) {
    n <- c(5L,10L,25L,39L,if (pattern=="remote") 57L else 59L)
    g <- expand.grid(missing=n,replicate=1:4,KEEP.OUT.ATTRS=FALSE)
    weight <- if (pattern=="remote") .10 else .20
    scenarios[[length(scenarios)+1L]] <- data.frame(pattern=pattern,g,weight=weight/nrow(g))
  }
  out <- do.call(rbind,scenarios)
  out$id <- sprintf("%s_%02d_%d",out$pattern,out$missing,out$replicate)
  stopifnot(abs(sum(out$weight)-1)<1e-12,!anyDuplicated(out$id))
  out
}

# R/phase51_fit.R:3-8
p51_feature_groups <- function() {
  base <- p45_groups()$fourier_pressure_season
  pcs <- paste0("pc",1:4)
  list(local=base, pc2=c(base,pcs[1:2]), pc4=c(base,pcs),
       gradient_pc4=c(base,"grad_east","grad_north",pcs))
}

# R/phase51_fit.R:13-25
p51_plane_weights <- function(geometry) {
  count <- nrow(geometry)
  patterns <- 0:(2^count-1L)
  weights <- array(0,c(length(patterns),count,2L))
  for (pattern in patterns) {
    keep <- as.logical(intToBits(pattern)[seq_len(count)])
    if (sum(keep)<4L) next
    probes <- diag(count)[keep,,drop=FALSE]
    probes[,!keep] <- NA_real_
    weights[pattern+1L,keep,] <- p5_pressure_slopes(probes,geometry)
  }
  weights
}

# R/phase51_fit.R:27-76
p51_regression_design <- function(fit, block, origins) {
  stopifnot(identical(block$neighbors,fit$prep$neighbors),
            identical(block$series,fit$series),
            identical(colnames(block$values),colnames(fit$prep$centers)),
            inherits(origins,"Date"),length(origins)>0L,!anyNA(origins),
            !anyDuplicated(origins),all(origins %in% block$dates))
  # The only measured values in this function are from the origin and previous date.
  local <- fit$series$column
  features <- fit$groups$gradient_pc4
  current <- p5_anomalies(block,fit$prep,origins,colnames(block$values))
  prior <- p5_anomalies(block,fit$prep,origins-1L,colnames(block$values))
  temps <- current[,rownames(fit$pc$loadings),drop=FALSE]
  coverage <- rowMeans(is.finite(temps) &
                      matrix(is.finite(fit$pc$sd),nrow(temps),ncol(temps),byrow=TRUE))
  scores <- p5_standardize(temps,fit$pc$center,fit$pc$sd) %*% fit$pc$loadings
  x <- array(0,c(length(origins),length(features),length(local)),
             dimnames=list(NULL,features,local))
  x[,colnames(scores),] <- scores
  geometry <- attr(fit$prep$neighbors,"pressure_geometry")
  for (airport in names(geometry)) {
    sensors <- geometry[[airport]]
    values <- current[,paste0(sensors$station,"_Mean.Sea.Level.PressureIn"),drop=FALSE]
    available <- is.finite(values)
    pattern <- as.integer(available %*% 2^(seq_len(ncol(values))-1L))+1L
    values[!available] <- 0
    w <- fit$plane_weights[[airport]]
    gradients <- vapply(1:2,function(axis) {
      weighted <- values * matrix(w[pattern,,axis,drop=FALSE],nrow=nrow(values))
      rowSums(weighted)
    }, numeric(nrow(values)))
    x[,c("grad_east","grad_north"),fit$series$airport==airport] <- gradients
  }
  current[!is.finite(current)] <- 0
  prior[!is.finite(prior)] <- 0
  x[,"lag1",] <- current[,local,drop=FALSE]
  x[,"lag2",] <- prior[,local,drop=FALSE]
  for (rank in 1:2) {
    peer_columns <- fit$peer_columns[[rank]]
    x[,paste0("peer",rank,"_lag1"),] <- current[,peer_columns,drop=FALSE]
    x[,paste0("peer",rank,"_lag2"),] <- prior[,peer_columns,drop=FALSE]
  }
  pressure <- current[,paste0(fit$series$airport,"_Mean.Sea.Level.PressureIn"),drop=FALSE]
  phase <- P45_BASIS[p45_calendar_index(origins),,drop=FALSE]
  x[,"pressure",] <- pressure
  x[,"pressure_cos",] <- pressure*phase[,"cos1"]
  x[,"pressure_sin",] <- pressure*phase[,"sin1"]
  base <- array(0,c(length(origins),5L,length(local)))
  for (h in 1:5) base[,h,] <- fit$prep$centers[p45_calendar_index(origins+h),local,drop=FALSE]
  list(x=x,base=base,coverage=unname(coverage))
}

# R/phase51_fit.R:78-127
p51_fit <- function(training,metadata,augmentation=TRUE,origins=NULL) {
  stopifnot(is.null(training$raw_targets),is.logical(augmentation),length(augmentation)==1L,
            !is.na(augmentation))
  years <- sort(unique(training$year))
  if (is.null(origins)) origins <- p3_year_origins(training,years,training=TRUE)
  stopifnot(all(calendar_day(origins) %in% 7:15),all(calendar_year(origins) %in% years))
  prep <- p45_preprocess(training,years,"fourier")
  temperatures <- paste0(ALL_AIRPORTS,"_Mean.TemperatureF")
  pc <- p5_fit_pc(p5_anomalies(training,prep,training$dates,temperatures))
  groups <- p51_feature_groups()
  features <- groups$gradient_pc4
  series <- training$series
  peers <- lapply(1:2,function(rank) {
    found <- prep$neighbors[prep$neighbors$rank==rank,]
    paste(found$peer[match(series$airport,found$airport)],TARGET_FIELDS[series$target],sep="_")
  })
  fit <- list(prep=prep,pc=pc,groups=groups,series=series,metadata=metadata,peer_columns=peers,
              plane_weights=lapply(attr(prep$neighbors,"pressure_geometry"),p51_plane_weights))
  stopifnot(identical(names(fit$plane_weights),TARGET_AIRPORTS))
  clean <- p51_regression_design(fit,training,origins)
  y <- p3_response_array(training$values,training$dates,origins,series$column)-clean$base
  methods <- names(groups)
  if (augmentation) {
    methods <- c(methods,"augmented")
    # Regression responses, including missing-value masks, always come from the
    # original training data. Artificially hidden observations affect inputs only.
    noisy <- lapply(1:2,function(k) {
      masked <- p51_apply_mask(training,metadata,c(0.10,0.25)[k],"mixed",k,"training")
      p51_regression_design(fit,masked,origins)$x
    })
  }
  coef <- array(0,c(length(features),5L,length(methods),nrow(series)),
                dimnames=list(features,as.character(1:5),methods,series$column))
  for (j in seq_len(nrow(series))) {
    x <- matrix(clean$x[,,j],ncol=length(features),dimnames=list(NULL,features))
    response <- matrix(y[,,j],ncol=5L)
    stub <- x[1,,drop=FALSE]
    model <- p3_fit_predict(x,response,stub,groups,ridge=numeric(),lasso=numeric())
    coef[,,names(groups),j] <- model$coefficients
    if (augmentation) {
      x_aug <- rbind(x,x,matrix(noisy[[1]][,,j],ncol=length(features)),
                     matrix(noisy[[2]][,,j],ncol=length(features)))
      y_aug <- response[rep(seq_len(nrow(response)),4L),,drop=FALSE]
      aug <- p3_fit_predict(x_aug,y_aug,stub,list(augmented=features),ridge=numeric(),lasso=numeric())
      coef[,,"augmented",j] <- aug$coefficients
    }
  }
  fit$coef <- coef
  fit
}

# R/phase51_policies.R:6-22
p51_order_matrix <- function(raw) {
  stopifnot(is.matrix(raw),nrow(raw)%%3L==0L,all(is.finite(raw)))
  i <- seq(1L,nrow(raw),3L)
  for (j in seq_len(ncol(raw))) {
    hi <- raw[i,j]; mid <- raw[i+1L,j]; lo <- raw[i+2L,j]
    lower <- lo>mid
    upper <- !lower & mid>hi
    if (!any(lower|upper)) next
    avg <- (mid+ifelse(lower,lo,hi))/2
    triple <- (lower & avg>hi) | (upper & avg<lo)
    joint <- (lo+mid+hi)/3
    raw[i,j] <- ifelse(triple,joint,ifelse(upper,avg,hi))
    raw[i+1L,j] <- ifelse(triple,joint,ifelse(lower|upper,avg,mid))
    raw[i+2L,j] <- ifelse(triple,joint,ifelse(lower,avg,lo))
  }
  raw
}

# R/phase51_interface.R:2-20
p51_input_manifest <- function(metadata) {
  peers <- p3_neighbors(metadata)
  local <- unique(c(TARGET_AIRPORTS,peers$peer))
  geometry <- p5_pressure_geometry(metadata)
  press <- unique(unlist(lapply(geometry, function(x) x$station), use.names=FALSE))
  info <- expand.grid(field=WEATHER_FIELDS, airport=ALL_AIRPORTS, stringsAsFactors=FALSE)
  info$column <- paste(info$airport,info$field,sep="_")
  info$target_airport <- info$airport %in% TARGET_AIRPORTS
  info$local_temperature_lag <- info$airport %in% local & info$field %in% TARGET_FIELDS
  info$pca_input <- info$field=="Mean.TemperatureF"
  info$local_pressure_level <- info$target_airport & info$field=="Mean.Sea.Level.PressureIn"
  info$gradient_input <- info$airport %in% press & info$field=="Mean.Sea.Level.PressureIn"
  info$qc_companion <- info$field %in% c("Max.TemperatureF","Min.TemperatureF") |
    (info$airport %in% press & info$field %in% c("Max.Sea.Level.PressureIn","Min.Sea.Level.PressureIn"))
  info$used <- with(info,local_temperature_lag | pca_input | local_pressure_level | gradient_input | qc_companion)
  info$software_only <- info$target_airport & info$field %in% c("Max.Humidity","Mean.Humidity","Min.Humidity",
      "Max.Dew.PointF","MeanDew.PointF","Min.DewpointF","Mean.Wind.SpeedMPH","Max.Wind.SpeedMPH","WindDirDegrees")
  info
}

# R/phase51_interface.R:24-60
p51_read_context <- function(path,year,metadata) {
  year <- valid_year(year)
  env <- new.env(parent=emptyenv())
  assert("weather" %in% load(path,envir=env), "Expected a weather data frame in the RDA")
  values <- env$weather
  assert(is.data.frame(values) && nrow(values)>0 && !anyDuplicated(names(values)),
         "Input must be a nonempty data frame with unique field names")
  dates_text <- rownames(values)
  assert(all(grepl("^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$",dates_text)), "Expected date row names")
  dates <- as.Date(dates_text,"%Y-%m-%d")
  assert(!anyNA(dates) && !anyDuplicated(dates) && all(diff(dates)>0) &&
           all(calendar_year(dates)==year), "Invalid, duplicate, out-of-order or mismatched-year dates")
  allowed <- calendar_day(dates)<=15L
  dates <- dates[allowed]
  assert(length(dates)==180L, "Need all twelve complete day 1-15 input blocks")
  manifest <- p51_input_manifest(metadata)
  unknown <- setdiff(names(values),manifest$column)
  assert(!length(unknown),paste("Unrecognized weather fields",paste(head(unknown,3),collapse=", ")))
  manifest$supplied_column <- manifest$column %in% names(values)
  incoming <- manifest$column[manifest$used & manifest$supplied_column]
  assert(length(incoming)>0L,"Input contains no recognized model measurement or QC companion")
  # Explicitly all-NA logical columns are a common R serialization of missing data.
  supplied <- values[allowed,incoming,drop=FALSE]
  for (name in names(supplied)) {
    z <- supplied[[name]]
    if (is.logical(z) && all(is.na(z))) supplied[[name]] <- rep(NA_real_,length(z))
    else assert(is.numeric(z) && !is.object(z) && is.null(dim(z)),paste("Numeric measurement required for",name))
  }
  manifest$finite_observations <- NA_integer_
  manifest$finite_observations[match(incoming,manifest$column)] <- vapply(supplied,function(z) sum(is.finite(z)),integer(1))
  # Populate only the numeric inputs needed by the shared row-local reader.
  # Excluded software-only features have no coefficients in any Phase 5.1 fit.
  needed <- manifest$column[manifest$used | manifest$software_only]
  additional <- setdiff(needed,names(supplied))
  supplied[additional] <- rep(list(rep(NA_real_,length(dates))),length(additional))
  list(data=new_weather(dates,supplied[needed]), manifest=manifest)
}

# R/phase6_features.R:12-28
p6_prepare <- function(training, metadata) {
  fit <- p51_fit(training, metadata, augmentation = FALSE)
  stations <- rownames(fit$pc$loadings)
  anomalies <- p5_anomalies(training, fit$prep, training$dates, stations)
  z <- p5_standardize(anomalies, fit$pc$center, fit$pc$sd)
  eig <- eigen(crossprod(z), symmetric = TRUE)
  extra <- eig$vectors[, 5:12, drop = FALSE]
  pivots <- apply(abs(extra), 2L, which.max)
  extra <- sweep(extra, 2L, sign(extra[cbind(pivots, seq_len(ncol(extra)))]), "*")
  extra[!is.finite(fit$pc$sd), ] <- 0
  extra[, eig$values[5:12] <= max(0, eig$values[1]) * 1e-12] <- 0
  dimnames(extra) <- list(stations, paste0("pc", 5:12))
  fit$pc12 <- cbind(fit$pc$loadings, extra)
  total <- sum(pmax(eig$values, 0))
  fit$pc12_fraction <- if (total > 0) pmax(eig$values[1:12], 0) / total else rep(0, 12)
  fit
}

# R/phase6_fit.R:106-111
p6_scenarios <- function() {
  all <- p51_scenarios()
  keep <- with(all,pattern=="original" | (pattern %in% c("random","cluster") & missing==25L) |
                 (pattern=="remote" & missing==57L & replicate==1L))
  all[keep,c("id","pattern","missing","replicate")]
}

# R/phase7_dynamics.R:4-10
p7_groups <- function() {
  base <- p51_feature_groups()$gradient_pc4
  motion <- c(base,paste0("dpc",1:4))
  list(control=base, motion4=motion, motion8=c(base,paste0("pc",5:8),paste0("dpc",1:4)),
       smooth4=c(base,paste0("two_day_pc",1:4)), lagged4=c(motion,paste0("previous_dpc",1:4)),
       regioncontrast=c(motion,"nearby_change_minus_local"))
}

# R/phase8_spatial.R:5-15
p8_groups <- function() {
  earlier <- p7_groups()
  base <- earlier$control
  motion <- earlier$motion4
  list(control=base, motion4=motion, motion8=earlier$motion8,
       change_basis=c(base,paste0("change_pc",1:4)),
       local_only=c(base,paste0("local_pc",1:2)),
       hybrid_now=c(motion,paste0("residual_pc",1:2)),
       hybrid_prior=c(motion,paste0("prior_residual_pc",1:2)),
       local_direct=c(motion,paste0("peer_residual",1:12)))
}

# R/phase8_spatial.R:19-30
p8_axes <- function(x,k) {
  stopifnot(is.matrix(x), all(is.finite(x)), k>=1L, k<=ncol(x))
  eig <- eigen(crossprod(x), symmetric=TRUE)
  active <- seq_len(k)
  axes <- eig$vectors[,active,drop=FALSE]
  pivot <- apply(abs(axes),2L,which.max)
  axes <- sweep(axes,2L,sign(axes[cbind(pivot,active)]),"*")
  axes[,eig$values[active]<=max(0,eig$values[1L])*1e-12] <- 0
  axes[colSums(x^2)==0,] <- 0
  dimnames(axes) <- list(colnames(x),paste0("pc",active))
  axes
}

# R/phase8_spatial.R:35-47
p8_change <- function(prepared,block,end_dates) {
  stations <- rownames(prepared$pc$loadings)
  current <- p5_anomalies(block,prepared$prep,end_dates,stations)
  previous <- p5_anomalies(block,prepared$prep,end_dates-1L,stations)
  sd <- prepared$pc$sd[stations]
  z <- sweep(current-previous,2L,sd,"/")
  observed <- is.finite(z) & matrix(is.finite(sd) & sd>0,nrow(z),ncol(z),byrow=TRUE)
  z[!observed] <- 0
  national <- z %*% prepared$pc$loadings
  residual <- z-tcrossprod(national,prepared$pc$loadings)
  residual[!observed] <- 0
  list(z=z, observed=observed, national=national, residual=residual)
}

# R/phase8_spatial.R:49-68
p8_prepare <- function(training,metadata) {
  stopifnot(is.null(training$raw_targets))
  prepared <- p6_prepare(training,metadata)
  dates <- training$dates
  stopifnot(!is.unsorted(dates,strictly=TRUE))
  paired <- which(as.integer(diff(dates))==1L &
                  head(training$year,-1L)==tail(training$year,-1L))+1L
  fields <- p8_change(prepared,training,dates[paired])
  ranked <- p51_mask_geometry(metadata)$near
  peers <- setNames(lapply(TARGET_AIRPORTS,function(airport) {
    ids <- head(setdiff(ranked[[match(airport,ALL_AIRPORTS)]],airport),12L)
    paste0(ids,"_Mean.TemperatureF")
  }),TARGET_AIRPORTS)
  prepared$spatial <- list(
    change_axes=p8_axes(fields$z,4),
    peers=peers,
    local_axes=lapply(peers,function(cols) p8_axes(fields$z[,cols,drop=FALSE],2)),
    residual_axes=lapply(peers,function(cols) p8_axes(fields$residual[,cols,drop=FALSE],2)))
  prepared
}

# R/phase8_spatial.R:70-104
p8_design <- function(prepared,block,origins) {
  stopifnot(is.null(block$raw_targets),all(calendar_day(origins) %in% 7:15))
  training <- block$year %in% prepared$prep$train_years
  stopifnot(all(training) || (!any(training) && all(block$day<=15L) &&
                                all(calendar_day(origins)==15L)))
  baseline <- p51_regression_design(prepared,block,origins)
  columns <- unique(unlist(p8_groups(),use.names=FALSE))
  x <- array(0,c(length(origins),length(columns),nrow(block$series)),
             dimnames=list(NULL,columns,block$series$column))
  x[,dimnames(baseline$x)[[2L]],] <- baseline$x

  stations <- rownames(prepared$pc12)
  levels <- p5_anomalies(block,prepared$prep,origins,stations)
  z <- p5_standardize(levels,prepared$pc$center,prepared$pc$sd)
  x[,paste0("pc",5:8),] <- z %*% prepared$pc12[,5:8,drop=FALSE]

  now <- p8_change(prepared,block,origins)
  prior <- p8_change(prepared,block,origins-1L)
  x[,paste0("dpc",1:4),] <- now$national
  spatial <- prepared$spatial
  x[,paste0("change_pc",1:4),] <- now$z %*% spatial$change_axes
  for (airport in names(spatial$peers)) {
    columns <- spatial$peers[[airport]]
    target <- block$series$airport==airport
    local <- now$z[,columns,drop=FALSE]
    residual <- now$residual[,columns,drop=FALSE]
    before <- prior$residual[,columns,drop=FALSE]
    axes <- spatial$residual_axes[[airport]]
    x[,paste0("local_pc",1:2),target] <- local %*% spatial$local_axes[[airport]]
    x[,paste0("residual_pc",1:2),target] <- residual %*% axes
    x[,paste0("prior_residual_pc",1:2),target] <- before %*% axes
    x[,paste0("peer_residual",1:12),target] <- residual
  }
  list(x=x,base=baseline$base,coverage=baseline$coverage)
}
